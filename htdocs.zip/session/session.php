<?php 
	include 'sessionFunctions.php';
	include $_SERVER['DOCUMENT_ROOT'].'/databases/usersDatabase.php';
	include $_SERVER['DOCUMENT_ROOT'].'/databases/historyDatabase.php';
	include $_SERVER['DOCUMENT_ROOT'].'/databases/ratingDatabase.php'; 
	include $_SERVER['DOCUMENT_ROOT'].'/databases/savedDatabase.php'; 

	date_default_timezone_set("Europe/Bucharest");

	$frequency = 10*60; // 10 minutes

	if (isSessionActive()) {
		regenerateSessionId($connection, $frequency);
		if (!connectedFromAnotherDevice($connection,  $_COOKIE['sessionId']))
			getSessionData($connection);
	} else
		stopSession($connection);
?>